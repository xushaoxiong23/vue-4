export function add(x,y){
	console.log(x + y);
}

export function substrict(x,y){
	console.log(x - y);
}

// export default{
// 	add,substrict
// }