// 1.0 定义add函数
function add(x, y) {
	return x + y
}

// 2.0 导出add方法
module.exports = add;
